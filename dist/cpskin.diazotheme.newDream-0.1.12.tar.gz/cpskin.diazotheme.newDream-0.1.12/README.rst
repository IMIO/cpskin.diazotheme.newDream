====================
cpskin.diazotheme.newDream
====================

This is a Cpskin Diazo theme

Installation
------------

Add this to your buildout.cfg, or do something equivalent

::

    develop += src/cpskin.diazotheme.newDream
    
    [instance]
    eggs += cpskin.diazotheme.newDream
    zcml += cpskin.diazotheme.newDream

Install the package in the quickinstaller

Activate the diazo theme

Screenshot
----------

.. image:: /cpskin/diazotheme/newDream/static/preview.png
