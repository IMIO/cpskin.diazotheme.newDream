from cpskin.agenda.browser.event_summary import EventContactSummaryView


class EventView(EventContactSummaryView):
    """
    """
